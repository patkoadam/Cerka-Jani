<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class StudentScheduleController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Ha nincs osztálycsoportja, 403
        if (! $user->classGroups->exists()) {
            abort(403, 'Nincs hozzárendelt osztályod.');
        }

        // Vegyük az első osztálycsoportot (ha csak 1 tagozatod van)
        $group = $user->classGroups->first();

        return Inertia::render('Orarend', [
            'classGroupId' => $group->id,
        ]);
    }
}

