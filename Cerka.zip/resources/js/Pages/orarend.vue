<template>
    <div class="schedule-container">
        <h2>Heti órarend</h2>

        <!-- heti navigáció -->
        <div class="d-flex justify-content-between mb-3">
            <button @click="prevWeek" class="btn btn-secondary">&laquo; Előző</button>
            <span>{{ weekDisplay }}</span>
            <button @click="nextWeek" class="btn btn-secondary">Következő &raquo;</button>
        </div>

        <div class="schedule-grid">
            <!-- időoszlop -->
            <div class="time-column">
                <div v-for="slot in timeSlots" :key="slot.time" class="time-slot">
                    {{ slot.time }}–{{ slot.endTime }}
                </div>
            </div>
            <!-- napok -->
            <div class="days-column">
                <div v-for="day in days" :key="day" class="day-column">
                    <h5>{{ day }}</h5>
                    <div v-for="slot in timeSlots" :key="slot.time" class="hour-cell">
                        <span v-if="assigned(day, slot.time)">
                            {{ assigned(day, slot.time).subject.name }}
                        </span>
                        <span v-else class="text-muted">–</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
  
<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'


export default {
    props: {
        classGroupId: Number,
    },
    setup(props) {
        const days = [
            "Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap"
        ]
        const timeSlots = [
            { time: "08:00", endTime: "08:40" },
            { time: "08:55", endTime: "09:35" },
            { time: "09:50", endTime: "10:30" },
            { time: "10:55", endTime: "11:35" },
            { time: "11:50", endTime: "12:30" },
            { time: "12:45", endTime: "13:25" },
            { time: "13:40", endTime: "14:20" },
            { time: "14:30", endTime: "15:10" },
            { time: "15:20", endTime: "16:00" },
            { time: "16:10", endTime: "16:50" },
            { time: "17:00", endTime: "17:40" },
            { time: "17:50", endTime: "18:30" },
            { time: "18:40", endTime: "19:20" }
        ]
        const currentMonday = ref(getMonday(new Date()))
        const assignments = ref([])

        const weekDisplay = () => {
            const start = currentMonday.value
            const end = new Date(start)
            end.setDate(start.getDate() + 6)
            return `${formatDate(start)} - ${formatDate(end)}`
        }

        function loadAssignments() {
            const start = formatDate(currentMonday.value)
            const d2 = new Date(currentMonday.value)
            d2.setDate(d2.getDate() + 6)
            const end = formatDate(d2)

            return axios.get(
                `/class-groups/${props.classGroupId}/schedules`,
                { params: { start, end } }
            ).then(r => {
                assignments.value = r.data
            })
        }

        function assigned(dayName, time) {
            return assignments.value.find(a => {
                // itt a ScheduleController `date` mezőt használja
                // mi pedig a frontend-en a nap neve alapján dolgozunk,
                // szúrjuk be a napnév szerinti összehasonlítást:
                return (
                    new Date(a.date).getDay() ===
                    ["Vasárnap", "Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat"]
                        .indexOf(dayName)
                    &&
                    a.time.slice(0, 5) === time
                )
            }) || null
        }

        function prevWeek() {
            const d = new Date(currentMonday.value)
            d.setDate(d.getDate() - 7)
            currentMonday.value = d
            loadAssignments()
        }
        function nextWeek() {
            const d = new Date(currentMonday.value)
            d.setDate(d.getDate() + 7)
            currentMonday.value = d
            loadAssignments()
        }

        onMounted(() => {
            loadAssignments()
        })

        return {
            days, timeSlots, currentMonday,
            weekDisplay, assigned,
            prevWeek, nextWeek
        }
    }
}

// segédfüggvények
function getMonday(d) {
    d = new Date(d)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1)
    return new Date(d.setDate(diff))
}
function formatDate(d) {
    const y = d.getFullYear()
    const m = String(d.getMonth() + 1).padStart(2, '0')
    const D = String(d.getDate()).padStart(2, '0')
    return `${y}-${m}-${D}`
}
</script>
  
<style scoped>
.schedule-container {
    padding: 20px;
    background: #fff;
    border-radius: 8px;
}

.schedule-grid {
    display: flex;
}

.time-column {
    width: 120px;
}

.time-slot {
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #E3E8F0;
    border-bottom: 1px solid #23395B;
    font-weight: bold;
}

.days-column {
    flex: 1;
    display: flex;
}

.day-column {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.hour-cell {
    height: 50px;
    border: 1px solid #23395B;
    background: #F0F4F8;
    display: flex;
    align-items: center;
    justify-content: center;
}

.text-muted {
    color: #999;
}
</style>
  