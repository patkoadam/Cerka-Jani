<template>
    Tanar jegyek
</template>
<script>
</script>
<style>
</style>